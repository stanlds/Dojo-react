import React from 'react'

function Error() {
    return (
        <h1>Lo ingresado no es un continente.</h1>
    )
}

export default Error
